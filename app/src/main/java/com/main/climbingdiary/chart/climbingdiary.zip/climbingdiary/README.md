<img src="info/logo.svg" width="200" style="margin-left:30%;">
<hr/>

Repsository für die Entwicklung der **Android-App** der gleichnamigen [Desktop-App](https://github.com/LorenMucha/Climbing-Diary). 
Die Anwendung befindet sich noch in der Entwicklungsphase und soll dem Nutzer alle Funktionen der Desktop Anwendung mit Synchronisierung bieten.
#### Funktionen
- Diagramme (Verlauf- und Balkendiagramm)
- Hinzufügen, verändern, löschen von Einträgen
- Suche nach Gebieten, Routen, Graden... 
#### Preview Screenshots
<img src="info/Screenshots_27032020/barchart.png" width="350">
<img src="info/Screenshots_27032020/tabelle.png" width="350">
<img src="info/Screenshots_27032020/linechart.png" width="350">
<img src="info/Screenshots_27032020/routen.png" width="350">
<img src="info/Screenshots_27032020/projects.png" width="350">
<img src="info/Screenshots_27032020/filter.png" width="350">

