package com.main.climbingdiary.chart

abstract class RouteChartController {
    abstract fun show()
    abstract fun hide()
    abstract fun createChart()
}