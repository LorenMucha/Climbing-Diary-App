package com.main.climbingdiary.models

enum class RouteType {
    ROUTE, PROJEKT
}