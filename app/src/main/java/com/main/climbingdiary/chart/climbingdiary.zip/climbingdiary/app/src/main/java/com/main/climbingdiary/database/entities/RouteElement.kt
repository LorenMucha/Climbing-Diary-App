package com.main.climbingdiary.database.entities

interface RouteElement {
}