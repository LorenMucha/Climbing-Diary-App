package com.main.climbingdiary.database;

public interface State {
    boolean getState();
}
