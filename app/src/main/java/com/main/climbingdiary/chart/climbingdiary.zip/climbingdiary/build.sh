cd app/src/main/assets/
rm touren.db
mv touren_empty.db touren.db