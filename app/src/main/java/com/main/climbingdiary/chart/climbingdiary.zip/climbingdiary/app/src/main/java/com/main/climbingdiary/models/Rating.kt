package com.main.climbingdiary.models

object Rating {
    fun getRating(): Array<String> {
        return arrayOf(
            "\u2605",
            "\u2605\u2605",
            "\u2605\u2605\u2605",
            "\u2605\u2605\u2605\u2605",
            "\u2605\u2605\u2605\u2605\u2605"
        )
    }
}